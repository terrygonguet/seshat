# Project [Seshat](https://en.wikipedia.org/wiki/Seshat)

A WebExtension to keep track of time spent on different projects.
